import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { StatCard } from "@/components/StatCard";
import { TodayStatusCard } from "@/components/TodayStatusCard";
import { QuickActionsPanel } from "@/components/QuickActionsPanel";
import { ActivityLogsTable } from "@/components/ActivityLogsTable";
import { ManualReminderDialog } from "@/components/ManualReminderDialog";
import { useToast } from "@/hooks/use-toast";
import {
  CheckCircle2,
  Clock,
  Bell,
  TrendingUp,
} from "lucide-react";
import type {
  DashboardStats,
  TodayStatus,
  ActivityLogEntry,
  TeamMember,
  ManualReminderRequest,
} from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const [logsPage, setLogsPage] = useState(1);
  const [reminderDialogOpen, setReminderDialogOpen] = useState(false);

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
  });

  const { data: todayStatus, isLoading: statusLoading } = useQuery<TodayStatus>({
    queryKey: ["/api/reports/today"],
  });

  const { data: logsData, isLoading: logsLoading } = useQuery<{
    logs: ActivityLogEntry[];
    totalPages: number;
  }>({
    queryKey: ["/api/reports/logs", logsPage],
    queryFn: async () => {
      const res = await fetch(`/api/reports/logs?page=${logsPage}`, {
        credentials: "include",
      });
      if (!res.ok) {
        throw new Error(`Failed to fetch logs: ${res.statusText}`);
      }
      return await res.json();
    },
  });

  const { data: teamMembers = [] } = useQuery<TeamMember[]>({
    queryKey: ["/api/team-members"],
  });

  const sendRemindersMutation = useMutation({
    mutationFn: async (data: ManualReminderRequest) => {
      return await apiRequest("POST", "/api/reminders/send", data);
    },
    onSuccess: () => {
      toast({
        title: "Reminders Sent",
        description: "AI-powered reminders have been sent successfully via Telegram.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reports/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reports/logs"] });
      setReminderDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send reminders. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSendReminders = () => {
    setReminderDialogOpen(true);
  };

  const handleViewLogs = () => {
    const logsSection = document.getElementById("activity-logs");
    logsSection?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">TS</span>
              </div>
              <div>
                <h1 className="text-lg font-bold">THE SHIFT</h1>
                <p className="text-xs text-muted-foreground">HR Dashboard</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-medium">
                {new Date().toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
              <p className="text-xs text-muted-foreground">Automated Team Compliance Tracking</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Submitted"
            value={statsLoading ? "..." : stats?.totalSubmitted || 0}
            icon={CheckCircle2}
          />
          <StatCard
            title="Pending Reports"
            value={statsLoading ? "..." : stats?.pendingReports || 0}
            icon={Clock}
          />
          <StatCard
            title="Reminders Sent Today"
            value={statsLoading ? "..." : stats?.remindersSentToday || 0}
            icon={Bell}
          />
          <StatCard
            title="Compliance Rate"
            value={statsLoading ? "..." : stats?.complianceRate || 0}
            suffix="%"
            icon={TrendingUp}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <TodayStatusCard status={todayStatus} isLoading={statusLoading} />
          </div>
          <div>
            <QuickActionsPanel
              onSendReminders={handleSendReminders}
              onViewLogs={handleViewLogs}
              isPending={sendRemindersMutation.isPending}
            />
          </div>
        </div>

        {/* Activity Logs Section */}
        <div id="activity-logs">
          <ActivityLogsTable
            logs={logsData?.logs || []}
            isLoading={logsLoading}
            currentPage={logsPage}
            totalPages={logsData?.totalPages || 1}
            onPageChange={setLogsPage}
          />
        </div>
      </main>

      {/* Manual Reminder Dialog */}
      <ManualReminderDialog
        open={reminderDialogOpen}
        onOpenChange={setReminderDialogOpen}
        teamMembers={teamMembers}
        onSubmit={(data) => sendRemindersMutation.mutate(data)}
        isPending={sendRemindersMutation.isPending}
      />
    </div>
  );
}
