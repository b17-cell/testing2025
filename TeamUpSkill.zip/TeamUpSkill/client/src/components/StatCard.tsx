import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface StatCardProps {
  title: string;
  value: number | string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  suffix?: string;
}

export function StatCard({ title, value, icon: Icon, trend, suffix }: StatCardProps) {
  return (
    <Card className="p-6 hover-elevate" data-testid={`stat-card-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 space-y-2">
          <p className="text-sm font-medium text-muted-foreground">
            {title}
          </p>
          <div className="flex items-baseline gap-2">
            <p className="text-3xl font-bold" data-testid={`stat-value-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {value}{suffix}
            </p>
            {trend && (
              <Badge 
                variant={trend.isPositive ? "default" : "secondary"}
                className="text-xs"
                data-testid="stat-trend"
              >
                {trend.isPositive ? "+" : ""}{trend.value}%
              </Badge>
            )}
          </div>
        </div>
        <div className="p-3 rounded-md bg-primary/10">
          <Icon className="w-5 h-5 text-primary" />
        </div>
      </div>
    </Card>
  );
}
