import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TeamMember } from "@shared/schema";

interface ManualReminderDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  teamMembers: TeamMember[];
  onSubmit: (data: {
    teamMemberIds: string[];
    customMessage?: string;
    aiTone: "professional" | "friendly" | "urgent";
  }) => void;
  isPending: boolean;
}

export function ManualReminderDialog({
  open,
  onOpenChange,
  teamMembers,
  onSubmit,
  isPending,
}: ManualReminderDialogProps) {
  const [selectedMembers, setSelectedMembers] = useState<string[]>([]);
  const [customMessage, setCustomMessage] = useState("");
  const [aiTone, setAiTone] = useState<"professional" | "friendly" | "urgent">("professional");

  const handleToggleMember = (memberId: string) => {
    setSelectedMembers((prev) =>
      prev.includes(memberId)
        ? prev.filter((id) => id !== memberId)
        : [...prev, memberId]
    );
  };

  const handleToggleAll = () => {
    if (selectedMembers.length === teamMembers.length) {
      setSelectedMembers([]);
    } else {
      setSelectedMembers(teamMembers.map((m) => m.id));
    }
  };

  const handleSubmit = () => {
    onSubmit({
      teamMemberIds: selectedMembers,
      customMessage: customMessage || undefined,
      aiTone,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]" data-testid="dialog-manual-reminder">
        <DialogHeader>
          <DialogTitle>Send Custom Reminders</DialogTitle>
          <DialogDescription>
            Select team members and customize the reminder message with AI assistance.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Team Members</Label>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleToggleAll}
                data-testid="button-select-all"
              >
                {selectedMembers.length === teamMembers.length
                  ? "Deselect All"
                  : "Select All"}
              </Button>
            </div>
            <div className="space-y-2 max-h-48 overflow-y-auto border border-border rounded-md p-3">
              {teamMembers.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center space-x-2"
                  data-testid={`checkbox-member-${member.id}`}
                >
                  <Checkbox
                    id={`member-${member.id}`}
                    checked={selectedMembers.includes(member.id)}
                    onCheckedChange={() => handleToggleMember(member.id)}
                  />
                  <Label
                    htmlFor={`member-${member.id}`}
                    className="flex-1 cursor-pointer font-normal"
                  >
                    {member.name}
                    {member.telegramUsername && (
                      <span className="text-xs text-muted-foreground ml-2">
                        @{member.telegramUsername}
                      </span>
                    )}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="ai-tone" className="text-sm font-medium">
              AI Message Tone
            </Label>
            <Select value={aiTone} onValueChange={(v: any) => setAiTone(v)}>
              <SelectTrigger id="ai-tone" data-testid="select-ai-tone">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="friendly">Friendly</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="custom-message" className="text-sm font-medium">
              Custom Message (Optional)
            </Label>
            <Textarea
              id="custom-message"
              placeholder="Leave blank to use AI-generated message based on selected tone..."
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              rows={4}
              data-testid="textarea-custom-message"
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isPending}
            data-testid="button-cancel-reminder"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={selectedMembers.length === 0 || isPending}
            data-testid="button-submit-reminder"
          >
            {isPending ? "Sending..." : "Send Reminders"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
