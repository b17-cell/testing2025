import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, FileText, Download } from "lucide-react";

interface QuickActionsPanelProps {
  onSendReminders: () => void;
  onViewLogs: () => void;
  isPending: boolean;
}

export function QuickActionsPanel({ onSendReminders, onViewLogs, isPending }: QuickActionsPanelProps) {
  return (
    <Card className="p-6" data-testid="quick-actions-panel">
      <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
      <div className="space-y-4">
        <Button
          onClick={onSendReminders}
          className="w-full"
          size="lg"
          disabled={isPending}
          data-testid="button-send-reminders"
        >
          <Bell className="w-4 h-4 mr-2" />
          {isPending ? "Sending..." : "Send Reminders Now"}
        </Button>
        
        <Button
          onClick={onViewLogs}
          variant="outline"
          className="w-full"
          size="lg"
          data-testid="button-view-logs"
        >
          <FileText className="w-4 h-4 mr-2" />
          View Full Logs
        </Button>

        <Button
          variant="outline"
          className="w-full"
          size="lg"
          data-testid="button-export-csv"
        >
          <Download className="w-4 h-4 mr-2" />
          Export to CSV
        </Button>
      </div>

      <div className="mt-6 p-4 rounded-md bg-muted/50 border border-border">
        <h4 className="text-sm font-medium mb-2">Next Scheduled Check</h4>
        <p className="text-xs text-muted-foreground">
          Daily at 5:00 PM (Automated)
        </p>
      </div>
    </Card>
  );
}
