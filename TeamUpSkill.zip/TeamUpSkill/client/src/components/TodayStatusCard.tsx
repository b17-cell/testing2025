import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, Clock } from "lucide-react";
import { TodayStatus } from "@shared/schema";

interface TodayStatusCardProps {
  status: TodayStatus | undefined;
  isLoading: boolean;
}

export function TodayStatusCard({ status, isLoading }: TodayStatusCardProps) {
  if (isLoading) {
    return (
      <Card className="p-8" data-testid="today-status-card">
        <div className="space-y-6 animate-pulse">
          <div className="h-8 bg-muted rounded w-1/2"></div>
          <div className="h-4 bg-muted rounded"></div>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-12 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </Card>
    );
  }

  if (!status) {
    return (
      <Card className="p-8" data-testid="today-status-card">
        <div className="text-center text-muted-foreground">
          No data available
        </div>
      </Card>
    );
  }

  const completionPercentage = status.totalMembers > 0 
    ? Math.round((status.submitted / status.totalMembers) * 100)
    : 0;

  return (
    <Card className="p-8" data-testid="today-status-card">
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold mb-2">Today's Status</h2>
          <p className="text-2xl font-bold" data-testid="text-today-submission-count">
            {status.submitted}/{status.totalMembers} Reports Submitted
          </p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Completion</span>
            <span className="font-medium" data-testid="text-completion-percentage">{completionPercentage}%</span>
          </div>
          <Progress value={completionPercentage} className="h-2" data-testid="progress-completion" />
        </div>

        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted-foreground">Team Members</h3>
          <div className="space-y-2">
            {status.members.map((member) => (
              <div
                key={member.id}
                className="flex items-center justify-between p-3 rounded-md bg-muted/30 hover-elevate"
                data-testid={`member-status-${member.id}`}
              >
                <div className="flex items-center gap-3">
                  {member.hasSubmitted ? (
                    <CheckCircle2 className="w-5 h-5 text-status-submitted" data-testid="icon-submitted" />
                  ) : (
                    <Clock className="w-5 h-5 text-status-pending" data-testid="icon-pending" />
                  )}
                  <div>
                    <p className="font-medium" data-testid={`text-member-name-${member.id}`}>
                      {member.name}
                    </p>
                    {member.telegramUsername && (
                      <p className="text-xs text-muted-foreground">
                        @{member.telegramUsername}
                      </p>
                    )}
                  </div>
                </div>
                <span
                  className={`text-sm font-medium ${
                    member.hasSubmitted ? "text-status-submitted" : "text-status-pending"
                  }`}
                  data-testid={`text-member-status-${member.id}`}
                >
                  {member.hasSubmitted ? "Submitted" : "Pending"}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}
