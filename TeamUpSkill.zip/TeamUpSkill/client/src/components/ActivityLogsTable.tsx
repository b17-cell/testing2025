import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { ActivityLogEntry } from "@shared/schema";
import { format } from "date-fns";

interface ActivityLogsTableProps {
  logs: ActivityLogEntry[];
  isLoading: boolean;
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export function ActivityLogsTable({ 
  logs, 
  isLoading, 
  currentPage, 
  totalPages, 
  onPageChange 
}: ActivityLogsTableProps) {
  if (isLoading) {
    return (
      <Card className="p-6" data-testid="activity-logs-table">
        <h3 className="text-lg font-semibold mb-4">Activity Logs</h3>
        <div className="space-y-3 animate-pulse">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-12 bg-muted rounded"></div>
          ))}
        </div>
      </Card>
    );
  }

  const getActionBadge = (action: string) => {
    const variants: Record<string, { variant: any; label: string }> = {
      submitted: { variant: "default", label: "Submitted" },
      reminded: { variant: "secondary", label: "Reminded" },
      missed: { variant: "destructive", label: "Missed" },
    };

    const config = variants[action] || { variant: "outline", label: action };
    return (
      <Badge variant={config.variant} className="text-xs font-medium">
        {config.label}
      </Badge>
    );
  };

  return (
    <Card className="p-6" data-testid="activity-logs-table">
      <h3 className="text-lg font-semibold mb-4">Activity Logs</h3>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left text-xs font-semibold uppercase text-muted-foreground pb-3 pr-4">
                Timestamp
              </th>
              <th className="text-left text-xs font-semibold uppercase text-muted-foreground pb-3 pr-4">
                Team Member
              </th>
              <th className="text-left text-xs font-semibold uppercase text-muted-foreground pb-3 pr-4">
                Action
              </th>
              <th className="text-left text-xs font-semibold uppercase text-muted-foreground pb-3">
                Message Preview
              </th>
            </tr>
          </thead>
          <tbody>
            {logs.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-8 text-center text-muted-foreground">
                  No activity logs found
                </td>
              </tr>
            ) : (
              logs.map((log) => (
                <tr 
                  key={log.id} 
                  className="border-b border-border hover-elevate"
                  data-testid={`log-row-${log.id}`}
                >
                  <td className="py-4 pr-4">
                    <span className="font-mono text-sm" data-testid={`log-timestamp-${log.id}`}>
                      {format(new Date(log.timestamp), "MMM dd, HH:mm")}
                    </span>
                  </td>
                  <td className="py-4 pr-4">
                    <span className="font-medium" data-testid={`log-member-${log.id}`}>
                      {log.teamMemberName}
                    </span>
                  </td>
                  <td className="py-4 pr-4">
                    {getActionBadge(log.action)}
                  </td>
                  <td className="py-4">
                    {log.messagePreview && (
                      <span className="text-sm text-muted-foreground line-clamp-1">
                        {log.messagePreview}
                      </span>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
          <span className="text-sm text-muted-foreground">
            Page {currentPage} of {totalPages}
          </span>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage === 1}
              data-testid="button-prev-page"
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              data-testid="button-next-page"
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </Card>
  );
}
