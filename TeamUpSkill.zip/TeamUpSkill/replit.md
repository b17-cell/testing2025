# THE SHIFT - HR AI Agent Dashboard

An automated HR compliance tracking system that checks daily reports from team members and sends AI-powered personalized reminders via Telegram.

## Features

- **Automated Daily Checks**: Scheduled cron job runs at 5:00 PM daily to check for missing reports
- **AI-Powered Reminders**: Uses Gemini AI to generate personalized, context-aware reminder messages
- **Telegram Integration**: Sends automated reminders directly to team members via Telegram
- **Google Sheets Integration**: Reads team member data and logs all reminders to Google Sheets
- **Real-time Dashboard**: Beautiful, professional dashboard showing:
  - Today's submission statistics
  - Team compliance rates
  - Activity logs with pagination
  - Manual reminder triggers

## Setup Instructions

### 1. Telegram Bot Setup

1. Open Telegram and search for `@BotFather`
2. Send `/newbot` command
3. Follow prompts to create your bot (e.g., "THE SHIFT HR Bot")
4. Copy the bot token (format: `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`)
5. Add token as `TELEGRAM_BOT_TOKEN` secret ✅ (Already configured)

### 2. Gemini API Setup

1. Visit https://aistudio.google.com/apikey
2. Sign in and create an API key
3. Copy the key (starts with `AIza...`)
4. Add as `GEMINI_API_KEY` secret ✅ (Already configured)

### 3. Google Sheets Setup (Optional)

The app works with sample data by default. To connect your own Google Sheet:

#### Step 1: Create Your Google Sheet

Create a new Google Sheet with three tabs:

**Tab 1: Team Members**
| Name | Telegram Chat ID | Telegram Username |
|------|------------------|-------------------|
| Sarah Johnson | 123456789 | sarahj |
| Michael Chen | 987654321 | mchen |

To get Telegram Chat IDs:
- Have each team member message your bot
- Use the Telegram API to get updates: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
- Look for the `chat.id` field in the response

**Tab 2: Daily Reports**
| Date | Name | Telegram Chat ID | Username | Submitted | Submitted At |
|------|------|------------------|----------|-----------|--------------|
| 2025-01-26 | Sarah Johnson | 123456789 | sarahj | Yes | 2025-01-26 14:30:00 |

**Tab 3: Reminder Logs**
| Date | Member Name | Reminder Sent At | Message Content | AI Tone |
|------|-------------|------------------|-----------------|---------|
| 2025-01-26 | Michael Chen | 2025-01-26 17:05:00 | Hi Michael... | friendly |

#### Step 2: Get Sheet ID

- Open your Google Sheet
- Copy the ID from the URL: `https://docs.google.com/spreadsheets/d/[THIS_IS_THE_ID]/edit`

#### Step 3: Add Environment Variable

Add `GOOGLE_SHEET_ID` as a Replit secret with your Sheet ID.

### 4. Get Team Member Chat IDs

To find each team member's Telegram chat ID:

1. Have them send a message to your bot (anything works, like "hi")
2. Visit: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
3. Find their chat ID in the JSON response under `message.chat.id`
4. Add to your Google Sheet or use the sample data

## Project Structure

```
├── client/                 # Frontend React app
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   │   ├── StatCard.tsx
│   │   │   ├── TodayStatusCard.tsx
│   │   │   ├── QuickActionsPanel.tsx
│   │   │   ├── ActivityLogsTable.tsx
│   │   │   └── ManualReminderDialog.tsx
│   │   ├── pages/
│   │   │   └── Dashboard.tsx
│   │   └── App.tsx
│   └── index.html
├── server/                # Backend Node.js/Express
│   ├── google-sheets.ts  # Google Sheets API integration
│   ├── telegram.ts       # Telegram Bot API
│   ├── gemini.ts         # Gemini AI for message generation
│   ├── storage.ts        # In-memory data storage
│   ├── routes.ts         # API endpoints
│   ├── cron.ts           # Scheduled jobs
│   └── index.ts          # Server entry point
└── shared/
    └── schema.ts         # Shared TypeScript types
```

## API Endpoints

- `GET /api/team-members` - Get all active team members
- `GET /api/stats` - Get dashboard statistics
- `GET /api/reports/today` - Get today's submission status
- `GET /api/reports/logs?page=1` - Get activity logs with pagination
- `POST /api/reminders/send` - Send manual reminders
- `POST /api/cron/check-reports` - Trigger automated check (called by cron)

## Automated Schedule

The system automatically checks for missing reports every day at **5:00 PM** and sends friendly reminders to team members who haven't submitted.

You can also trigger manual reminders anytime from the dashboard with custom AI tones:
- **Professional**: Formal, workplace-appropriate
- **Friendly**: Warm, encouraging, motivating
- **Urgent**: Emphasizes importance while remaining respectful

## Development

The app uses:
- **Frontend**: React, TypeScript, Tailwind CSS, Shadcn UI
- **Backend**: Express, Node.js, TypeScript
- **APIs**: Google Sheets, Telegram Bot, Gemini AI
- **Scheduling**: node-cron for automated daily checks
- **Storage**: In-memory (MemStorage) for development

## Current Configuration

✅ GEMINI_API_KEY - Configured
✅ TELEGRAM_BOT_TOKEN - Configured
✅ Google Sheets Connector - Authorized
⚠️  GOOGLE_SHEET_ID - Using sample data (optional: add your Sheet ID)

## Next Steps

1. **Add your Google Sheet ID** (optional) to connect real data
2. **Get team member Telegram chat IDs** following instructions above
3. **Test manual reminders** from the dashboard
4. **Wait for 5:00 PM** to see automated reminders in action

The dashboard is fully functional with sample data, so you can explore all features immediately!

## Production Launch Checklist

Before deploying to production, ensure the following:

### ✅ Environment Secrets
- [x] `GEMINI_API_KEY` - Configured
- [x] `TELEGRAM_BOT_TOKEN` - Configured
- [ ] `GOOGLE_SHEET_ID` - Add your Google Sheet ID
- [x] `SESSION_SECRET` - Already configured

### ✅ Google Sheets Setup
1. Create Google Sheet with three tabs:
   - Team Members (Name, Telegram Chat ID, Telegram Username)
   - Daily Reports (Date, Name, Chat ID, Username, Submitted, Submitted At)
   - Reminder Logs (Date, Member Name, Reminder Sent At, Message Content, AI Tone)
2. Share sheet with service account email from Google Sheets connector
3. Add `GOOGLE_SHEET_ID` environment variable

### ✅ Telegram Onboarding
1. Send your bot link to all team members
2. Have each member start a conversation with the bot
3. Get their chat IDs using: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
4. Add chat IDs to your Google Sheet

### ✅ Testing & Monitoring
- Test manual reminder flow from dashboard
- Verify AI message generation with all three tones
- Confirm Telegram messages deliver successfully
- Monitor cron job execution at 5:00 PM daily
- Check server logs for any API failures
- Review activity logs for reminder history

### ✅ Deployment
- Use Replit's "Publish" feature to deploy
- Set up custom domain (optional)
- Enable Always On for 24/7 cron scheduling
- Monitor application logs regularly

## Monitoring & Maintenance

### Daily Checks
- Review activity logs for failed reminders
- Monitor team submission compliance rates
- Check for any API errors in server logs

### Weekly Review
- Review overall team compliance trends
- Adjust reminder timing if needed (edit `server/cron.ts`)
- Update AI tone preferences based on team feedback

### Log Retention
- Activity logs are stored in Google Sheets indefinitely
- In-memory storage resets on server restart (production should use database)
- Consider archiving old logs monthly

### Troubleshooting

**Reminders not sending:**
- Verify `TELEGRAM_BOT_TOKEN` is correct
- Check team member chat IDs are accurate
- Review server logs for API errors

**Google Sheets errors:**
- Confirm service account has sheet access
- Verify `GOOGLE_SHEET_ID` is correct
- Check sheet tab names match exactly

**AI message generation issues:**
- Verify `GEMINI_API_KEY` is valid
- Check API quota/rate limits
- Review Gemini AI error messages in logs

**Cron not running:**
- Enable "Always On" in Replit deployment settings
- Verify server timezone matches expectation
- Check cron schedule in `server/cron.ts`
