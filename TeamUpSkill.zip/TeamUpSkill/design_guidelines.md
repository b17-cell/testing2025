# Design Guidelines for THE SHIFT HR AI Agent Dashboard

## Design Approach

**Selected Framework**: Fluent Design System
**Justification**: This is an information-dense productivity tool for internal team management. Fluent Design excels at enterprise dashboards with its clear hierarchy, efficient data presentation, and professional aesthetic suitable for business applications.

**Design Principles**:
1. **Clarity First**: Every element serves a functional purpose in communicating report status
2. **Scannable Hierarchy**: Critical information (today's status) prominently displayed, supporting details accessible
3. **Professional Efficiency**: Clean, business-appropriate interface that respects user time
4. **Status-Driven Design**: Visual system that makes compliance status immediately apparent

---

## Typography

**Font Families** (via Google Fonts CDN):
- **Primary**: Inter (400, 500, 600, 700) - for all UI elements, data displays
- **Monospace**: JetBrains Mono (400, 500) - for logs, timestamps, technical data

**Type Scale**:
- **Dashboard Title**: text-3xl font-bold (THE SHIFT HR Dashboard)
- **Section Headers**: text-xl font-semibold (Today's Status, Team Overview)
- **Card Titles**: text-lg font-medium (Report Statistics, Recent Activity)
- **Body Text**: text-base font-normal (descriptions, labels)
- **Data Values**: text-2xl font-bold (statistics numbers)
- **Metadata**: text-sm font-medium (timestamps, status labels)
- **Helper Text**: text-xs (table headers, secondary info)

---

## Layout System

**Spacing Primitives**: Tailwind units of **2, 4, 6, 8, 12, 16**
- Component padding: p-6 to p-8
- Section spacing: space-y-6 to space-y-8
- Card gaps: gap-6
- Button padding: px-6 py-2 to px-8 py-3
- Icon spacing: mr-2, ml-2

**Grid Structure**:
- Main container: max-w-7xl mx-auto px-6
- Dashboard grid: grid grid-cols-1 lg:grid-cols-3 gap-6
- Stats grid: grid grid-cols-2 md:grid-cols-4 gap-4

---

## Component Library

### A. Navigation & Header

**Top Navigation Bar**:
- Full-width header with backdrop blur effect
- Left: THE SHIFT logo + "HR Dashboard" title
- Center: Current date display with auto-refresh indicator
- Right: Manual trigger button + user profile icon
- Height: h-16, sticky top-0

### B. Dashboard Cards

**Stat Cards** (4 across on desktop):
- Card structure: rounded-xl border with subtle shadow
- Icon + Label + Large Number + Trend indicator
- Cards: "Total Submitted", "Pending Reports", "Reminders Sent Today", "Compliance Rate"
- Each card: min-h-32 with centered content
- Number prominence: text-3xl font-bold
- Percentage badges for trends

**Status Overview Card**:
- Large card spanning 2/3 width on desktop
- Real-time status: "3/5 Reports Submitted Today"
- Visual progress bar showing completion percentage
- List of team members with status indicators (checkmark/warning icon)
- Height: min-h-64

**Quick Actions Panel**:
- Sidebar card (1/3 width on desktop)
- Primary: "Send Reminders Now" button (full-width, prominent)
- Secondary: "View Full Logs" link
- Tertiary: "Export to CSV" option
- Spacing: space-y-4 between actions

### C. Data Tables

**Logs Table**:
- Full-width table with alternating row backgrounds
- Columns: Timestamp (monospace), Team Member, Action Type, Status, AI Message Preview
- Table headers: text-xs uppercase font-semibold with bottom border
- Rows: hover state with subtle background change
- Pagination controls at bottom: Previous/Next buttons + page indicator

**Team Management Table**:
- Columns: Name, Last Submitted, Streak Count, Reminders This Week, Status Badge
- Status badges: rounded-full px-3 py-1 with status-specific styling
- Sortable columns with arrow indicators
- Row height: py-4 for touch-friendly interaction

### D. Forms & Controls

**Manual Trigger Section**:
- Card with form layout
- Checkbox list for team member selection (with "Select All" toggle)
- Textarea for custom message override (optional)
- AI tone selector: dropdown with options (Professional, Friendly, Urgent)
- Submit button: "Send Custom Reminder" - full-width, primary style

### E. Status Indicators

**Badge System**:
- Submitted: rounded-full badge with checkmark icon
- Pending: outlined badge with clock icon  
- Reminded: filled badge with bell icon
- Late: filled badge with warning icon
- Each badge: px-3 py-1 text-sm font-medium

**Icons** (Heroicons via CDN):
- CheckCircle: submitted reports
- Clock: pending status
- Bell: reminders sent
- ExclamationTriangle: late/missing
- UserGroup: team overview
- ChartBar: statistics
- Cog: settings/manual controls

### F. Data Visualization

**Progress Bars**:
- Completion progress: h-2 rounded-full with fill animation
- Weekly compliance trend: h-1 mini bars for each day

**Sparkline Charts** (optional enhancement):
- Small line charts showing 7-day submission trends
- Displayed within stat cards as visual context

---

## Page Structure

**Main Dashboard Layout**:

1. **Header Section** (sticky, h-16)
2. **Stats Row** (4 stat cards, grid-cols-4)
3. **Main Content Grid** (2-column on desktop):
   - Left (2/3 width): Today's Status Card + Recent Logs Table
   - Right (1/3 width): Quick Actions Panel
4. **Team Management Section** (full-width table)
5. **Activity Log Section** (full-width, paginated table)

**Vertical Rhythm**: py-8 between major sections, py-6 for subsections

---

## Interaction Patterns

**Real-time Updates**:
- Auto-refresh badge in header (pulsing dot when active)
- Toast notifications for successful actions (top-right corner)
- Loading states: skeleton screens for data tables

**Button States**:
- Primary buttons: solid background with depth
- Hover: slight scale (scale-105) + shadow increase
- Active: scale-95 for tactile feedback
- Disabled: reduced opacity (opacity-50) + cursor-not-allowed

**Table Interactions**:
- Row hover: background lightening
- Sortable headers: clickable with arrow icon rotation
- Expandable rows: click to show full AI message content

---

## Responsive Behavior

**Desktop (lg+)**: Full 3-column layout with sidebar
**Tablet (md)**: 2-column grid, actions panel below content
**Mobile (base)**: Single column stack, sticky header, condensed tables (horizontal scroll or stacked cards)

**Breakpoint Strategy**:
- Stats: grid-cols-2 md:grid-cols-4
- Main content: grid-cols-1 lg:grid-cols-3
- Tables: overflow-x-auto on mobile with min-width enforcement

---

## Visual Enhancements

**Animations**: Minimal, purposeful only
- Stat number counting animation on load (quick, 0.5s)
- Smooth transitions for hover states (transition-all duration-200)
- Toast slide-in/fade-out for notifications

**Depth & Hierarchy**:
- Cards: shadow-sm for base state, shadow-md on hover
- Active elements: shadow-lg
- Tables: border separation rather than heavy shadows

---

## THE SHIFT Branding Integration

**Logo Placement**: Top-left of header, h-8 size
**Brand Voice**: Professional yet approachable (reflected in AI message tone options)
**Tagline/Subtitle**: "Automated Team Compliance Tracking" beneath dashboard title

---

This design creates a professional, efficiency-focused dashboard that prioritizes quick status comprehension while maintaining the polish expected from a marketing agency's internal tools. Every element serves the core goal: making team compliance immediately visible and actionable.