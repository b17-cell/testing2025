import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Team Members
export const teamMembers = pgTable("team_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  telegramChatId: text("telegram_chat_id").notNull().unique(),
  telegramUsername: text("telegram_username"),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({
  id: true,
});

export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;

// Daily Reports
export const dailyReports = pgTable("daily_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamMemberId: varchar("team_member_id").notNull().references(() => teamMembers.id),
  reportDate: timestamp("report_date", { mode: "date" }).notNull(),
  submittedAt: timestamp("submitted_at").notNull().defaultNow(),
  content: text("content"),
});

export const insertDailyReportSchema = createInsertSchema(dailyReports).omit({
  id: true,
  submittedAt: true,
});

export type InsertDailyReport = z.infer<typeof insertDailyReportSchema>;
export type DailyReport = typeof dailyReports.$inferSelect;

// Reminder Logs
export const reminderLogs = pgTable("reminder_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamMemberId: varchar("team_member_id").notNull().references(() => teamMembers.id),
  sentAt: timestamp("sent_at").notNull().defaultNow(),
  reportDate: timestamp("report_date", { mode: "date" }).notNull(),
  messageContent: text("message_content").notNull(),
  aiTone: text("ai_tone").notNull(),
  status: text("status").notNull().default("sent"),
});

export const insertReminderLogSchema = createInsertSchema(reminderLogs).omit({
  id: true,
  sentAt: true,
});

export type InsertReminderLog = z.infer<typeof insertReminderLogSchema>;
export type ReminderLog = typeof reminderLogs.$inferSelect;

// API Response Types
export interface DashboardStats {
  totalSubmitted: number;
  pendingReports: number;
  remindersSentToday: number;
  complianceRate: number;
}

export interface TodayStatus {
  date: string;
  totalMembers: number;
  submitted: number;
  pending: number;
  members: Array<{
    id: string;
    name: string;
    hasSubmitted: boolean;
    telegramUsername?: string;
  }>;
}

export interface ActivityLogEntry {
  id: string;
  timestamp: string;
  teamMemberName: string;
  action: "submitted" | "reminded" | "missed";
  status: string;
  messagePreview?: string;
}

export interface TeamMemberWithStats extends TeamMember {
  lastSubmitted?: string;
  streakCount: number;
  remindersThisWeek: number;
  complianceRate: number;
}

// Manual Reminder Request
export const manualReminderSchema = z.object({
  teamMemberIds: z.array(z.string()).min(1, "Select at least one team member"),
  customMessage: z.string().optional(),
  aiTone: z.enum(["professional", "friendly", "urgent"]).default("professional"),
});

export type ManualReminderRequest = z.infer<typeof manualReminderSchema>;
