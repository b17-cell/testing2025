import { 
  type TeamMember, 
  type InsertTeamMember,
  type DailyReport,
  type InsertDailyReport,
  type ReminderLog,
  type InsertReminderLog,
  type TeamMemberWithStats,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Team Members
  getTeamMembers(): Promise<TeamMember[]>;
  getTeamMember(id: string): Promise<TeamMember | undefined>;
  createTeamMember(member: InsertTeamMember): Promise<TeamMember>;

  // Daily Reports
  getReportsByDate(date: Date): Promise<DailyReport[]>;
  createReport(report: InsertDailyReport): Promise<DailyReport>;
  
  // Reminder Logs
  getReminderLogs(limit?: number, offset?: number): Promise<ReminderLog[]>;
  getReminderLogsByDate(date: Date): Promise<ReminderLog[]>;
  createReminderLog(log: InsertReminderLog): Promise<ReminderLog>;
  
  // Stats
  getTeamMembersWithStats(): Promise<TeamMemberWithStats[]>;
}

export class MemStorage implements IStorage {
  private teamMembers: Map<string, TeamMember>;
  private dailyReports: Map<string, DailyReport>;
  private reminderLogs: Map<string, ReminderLog>;

  constructor() {
    this.teamMembers = new Map();
    this.dailyReports = new Map();
    this.reminderLogs = new Map();
  }

  async getTeamMembers(): Promise<TeamMember[]> {
    return Array.from(this.teamMembers.values()).filter(m => m.isActive);
  }

  async getTeamMember(id: string): Promise<TeamMember | undefined> {
    return this.teamMembers.get(id);
  }

  async createTeamMember(insertMember: InsertTeamMember): Promise<TeamMember> {
    const id = randomUUID();
    const member: TeamMember = { 
      ...insertMember, 
      id,
      isActive: insertMember.isActive ?? true,
    };
    this.teamMembers.set(id, member);
    return member;
  }

  async getReportsByDate(date: Date): Promise<DailyReport[]> {
    const dateStr = date.toISOString().split('T')[0];
    return Array.from(this.dailyReports.values()).filter(report => {
      const reportDateStr = new Date(report.reportDate).toISOString().split('T')[0];
      return reportDateStr === dateStr;
    });
  }

  async createReport(insertReport: InsertDailyReport): Promise<DailyReport> {
    const id = randomUUID();
    const report: DailyReport = {
      ...insertReport,
      id,
      submittedAt: new Date(),
    };
    this.dailyReports.set(id, report);
    return report;
  }

  async getReminderLogs(limit: number = 50, offset: number = 0): Promise<ReminderLog[]> {
    const logs = Array.from(this.reminderLogs.values())
      .sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());
    return logs.slice(offset, offset + limit);
  }

  async getReminderLogsByDate(date: Date): Promise<ReminderLog[]> {
    const dateStr = date.toISOString().split('T')[0];
    return Array.from(this.reminderLogs.values()).filter(log => {
      const logDateStr = new Date(log.reportDate).toISOString().split('T')[0];
      return logDateStr === dateStr;
    });
  }

  async createReminderLog(insertLog: InsertReminderLog): Promise<ReminderLog> {
    const id = randomUUID();
    const log: ReminderLog = {
      ...insertLog,
      id,
      sentAt: new Date(),
      status: insertLog.status || "sent",
    };
    this.reminderLogs.set(id, log);
    return log;
  }

  async getTeamMembersWithStats(): Promise<TeamMemberWithStats[]> {
    const members = await this.getTeamMembers();
    const allReports = Array.from(this.dailyReports.values());
    const allReminders = Array.from(this.reminderLogs.values());

    return members.map(member => {
      const memberReports = allReports.filter(r => r.teamMemberId === member.id);
      const memberReminders = allReminders.filter(r => r.teamMemberId === member.id);
      
      // Calculate last submitted date
      const sortedReports = memberReports.sort((a, b) => 
        new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()
      );
      const lastSubmitted = sortedReports[0]?.submittedAt.toISOString();

      // Calculate streak (consecutive days with reports)
      let streakCount = 0;
      const today = new Date();
      for (let i = 0; i < 30; i++) {
        const checkDate = new Date(today);
        checkDate.setDate(checkDate.getDate() - i);
        const dateStr = checkDate.toISOString().split('T')[0];
        const hasReport = memberReports.some(r => 
          new Date(r.reportDate).toISOString().split('T')[0] === dateStr
        );
        if (hasReport) {
          streakCount++;
        } else {
          break;
        }
      }

      // Reminders this week
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const remindersThisWeek = memberReminders.filter(r => 
        new Date(r.sentAt) > weekAgo
      ).length;

      // Compliance rate (last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      const recentReports = memberReports.filter(r => 
        new Date(r.reportDate) > thirtyDaysAgo
      ).length;
      const complianceRate = Math.round((recentReports / 30) * 100);

      return {
        ...member,
        lastSubmitted,
        streakCount,
        remindersThisWeek,
        complianceRate,
      };
    });
  }
}

export const storage = new MemStorage();
