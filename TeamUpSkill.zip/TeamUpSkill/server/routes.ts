import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  getTeamMembersFromSheet,
  getTodayReportsFromSheet,
  logReminderToSheet,
  getAllReminderLogsFromSheet,
} from "./google-sheets";
import { sendTelegramMessage } from "./telegram";
import { generateReminderMessage } from "./gemini";
import { 
  type DashboardStats,
  type TodayStatus,
  type ActivityLogEntry,
  manualReminderSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize team members from Google Sheets on startup
  initializeTeamMembers();

  // GET /api/team-members - Get all active team members
  app.get("/api/team-members", async (req, res) => {
    try {
      const members = await storage.getTeamMembers();
      res.json(members);
    } catch (error: any) {
      console.error("Error fetching team members:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/stats - Get dashboard statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const today = new Date();
      const todayReports = await storage.getReportsByDate(today);
      const teamMembers = await storage.getTeamMembers();
      const todayReminders = await storage.getReminderLogsByDate(today);

      const stats: DashboardStats = {
        totalSubmitted: todayReports.length,
        pendingReports: teamMembers.length - todayReports.length,
        remindersSentToday: todayReminders.length,
        complianceRate: teamMembers.length > 0 
          ? Math.round((todayReports.length / teamMembers.length) * 100)
          : 0,
      };

      res.json(stats);
    } catch (error: any) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/reports/today - Get today's submission status
  app.get("/api/reports/today", async (req, res) => {
    try {
      const today = new Date();
      const teamMembers = await storage.getTeamMembers();
      const todayReports = await storage.getReportsByDate(today);
      
      const reportedMemberIds = new Set(todayReports.map(r => r.teamMemberId));

      const status: TodayStatus = {
        date: today.toISOString().split('T')[0],
        totalMembers: teamMembers.length,
        submitted: todayReports.length,
        pending: teamMembers.length - todayReports.length,
        members: teamMembers.map(member => ({
          id: member.id,
          name: member.name,
          hasSubmitted: reportedMemberIds.has(member.id),
          telegramUsername: member.telegramUsername,
        })),
      };

      res.json(status);
    } catch (error: any) {
      console.error("Error fetching today's status:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // GET /api/reports/logs - Get activity logs with pagination
  app.get("/api/reports/logs", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = 10;
      const offset = (page - 1) * pageSize;

      const allLogs = await storage.getReminderLogs(1000, 0);
      const totalLogs = allLogs.length;
      const paginatedLogs = allLogs.slice(offset, offset + pageSize);

      const teamMembers = await storage.getTeamMembers();
      const memberMap = new Map(teamMembers.map(m => [m.id, m.name]));

      const logs: ActivityLogEntry[] = paginatedLogs.map(log => ({
        id: log.id,
        timestamp: log.sentAt.toISOString(),
        teamMemberName: memberMap.get(log.teamMemberId) || "Unknown",
        action: "reminded" as const,
        status: log.status,
        messagePreview: log.messageContent.substring(0, 100),
      }));

      res.json({
        logs,
        totalPages: Math.ceil(totalLogs / pageSize),
      });
    } catch (error: any) {
      console.error("Error fetching logs:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/reminders/send - Send manual reminders
  app.post("/api/reminders/send", async (req, res) => {
    try {
      const validationResult = manualReminderSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ error: validationResult.error.message });
      }

      const { teamMemberIds, customMessage, aiTone } = validationResult.data;
      const today = new Date();
      const members = await storage.getTeamMembers();

      const selectedMembers = members.filter(m => teamMemberIds.includes(m.id));
      
      const reminders = await Promise.all(
        selectedMembers.map(async (member) => {
          try {
            // Generate AI message
            const message = await generateReminderMessage(
              member.name,
              aiTone,
              customMessage
            );

            // Send via Telegram
            await sendTelegramMessage(member.telegramChatId, message);

            // Log to storage
            await storage.createReminderLog({
              teamMemberId: member.id,
              reportDate: today,
              messageContent: message,
              aiTone,
              status: "sent",
            });

            // Log to Google Sheets
            await logReminderToSheet({
              date: today.toISOString().split('T')[0],
              memberName: member.name,
              reminderSentAt: new Date().toISOString(),
              messageContent: message,
              aiTone,
            });

            return { success: true, memberId: member.id };
          } catch (error) {
            console.error(`Failed to send reminder to ${member.name}:`, error);
            return { success: false, memberId: member.id, error };
          }
        })
      );

      const successCount = reminders.filter(r => r.success).length;
      
      res.json({
        message: `Sent ${successCount}/${reminders.length} reminders successfully`,
        results: reminders,
      });
    } catch (error: any) {
      console.error("Error sending reminders:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Automated cron job will call this endpoint
  app.post("/api/cron/check-reports", async (req, res) => {
    try {
      await checkAndSendReminders();
      res.json({ message: "Cron job executed successfully" });
    } catch (error: any) {
      console.error("Error in cron job:", error);
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to initialize team members from Google Sheets
async function initializeTeamMembers() {
  try {
    console.log("📋 Initializing team members from Google Sheets...");
    const sheetMembers = await getTeamMembersFromSheet();
    
    for (const sheetMember of sheetMembers) {
      const existing = await storage.getTeamMembers();
      const found = existing.find(m => m.telegramChatId === sheetMember.telegramChatId);
      
      if (!found) {
        await storage.createTeamMember({
          name: sheetMember.name,
          telegramChatId: sheetMember.telegramChatId,
          telegramUsername: sheetMember.telegramUsername,
          isActive: true,
        });
        console.log(`✅ Added team member: ${sheetMember.name}`);
      }
    }
    
    console.log("✅ Team members initialized");
    
    // Add sample reminder logs for testing pagination
    await createSampleReminderLogs();
  } catch (error) {
    console.error("❌ Error initializing team members:", error);
  }
}

// Create sample reminder logs for testing
async function createSampleReminderLogs() {
  try {
    const members = await storage.getTeamMembers();
    if (members.length === 0) return;

    console.log("📝 Creating sample reminder logs for testing...");
    
    // Create 25 sample logs to test pagination (10 per page)
    for (let i = 0; i < 25; i++) {
      const member = members[i % members.length];
      const daysAgo = Math.floor(i / members.length);
      const logDate = new Date();
      logDate.setDate(logDate.getDate() - daysAgo);
      
      await storage.createReminderLog({
        teamMemberId: member.id,
        reportDate: logDate,
        messageContent: `Sample reminder ${i + 1}: Hi ${member.name}, this is a friendly reminder to submit your daily report. Keep up the great work!`,
        aiTone: i % 3 === 0 ? "professional" : i % 3 === 1 ? "friendly" : "urgent",
        status: "sent",
      });
    }
    
    console.log("✅ Sample reminder logs created");
  } catch (error) {
    console.error("❌ Error creating sample logs:", error);
  }
}

// Automated checking and reminder function
export async function checkAndSendReminders() {
  console.log("🤖 Running automated report check...");
  
  try {
    const today = new Date();
    const teamMembers = await storage.getTeamMembers();
    const todayReports = await storage.getReportsByDate(today);
    
    const reportedMemberIds = new Set(todayReports.map(r => r.teamMemberId));
    const membersWithoutReports = teamMembers.filter(m => !reportedMemberIds.has(m.id));

    console.log(`📊 Found ${membersWithoutReports.length} members without reports`);

    for (const member of membersWithoutReports) {
      try {
        const message = await generateReminderMessage(member.name, "friendly");
        await sendTelegramMessage(member.telegramChatId, message);
        
        await storage.createReminderLog({
          teamMemberId: member.id,
          reportDate: today,
          messageContent: message,
          aiTone: "friendly",
          status: "sent",
        });

        await logReminderToSheet({
          date: today.toISOString().split('T')[0],
          memberName: member.name,
          reminderSentAt: new Date().toISOString(),
          messageContent: message,
          aiTone: "friendly",
        });

        console.log(`✅ Sent reminder to ${member.name}`);
      } catch (error) {
        console.error(`❌ Failed to send reminder to ${member.name}:`, error);
      }
    }

    console.log("✅ Automated check complete");
  } catch (error) {
    console.error("❌ Error in automated check:", error);
    throw error;
  }
}
