// Telegram Bot API integration
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const TELEGRAM_API_URL = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;

export interface TelegramMessage {
  chatId: string;
  text: string;
}

export async function sendTelegramMessage(chatId: string, text: string): Promise<void> {
  try {
    const response = await fetch(`${TELEGRAM_API_URL}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: text,
        parse_mode: 'Markdown',
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Telegram API error: ${JSON.stringify(error)}`);
    }

    const result = await response.json();
    console.log(`✅ Telegram message sent to chat ${chatId}`);
    return result;
  } catch (error) {
    console.error(`Error sending Telegram message to ${chatId}:`, error);
    throw error;
  }
}

export async function sendBulkTelegramMessages(messages: TelegramMessage[]): Promise<void> {
  const results = await Promise.allSettled(
    messages.map(msg => sendTelegramMessage(msg.chatId, msg.text))
  );

  const failed = results.filter(r => r.status === 'rejected');
  if (failed.length > 0) {
    console.error(`${failed.length} Telegram messages failed to send`);
  }

  console.log(`✅ Sent ${results.length - failed.length}/${results.length} Telegram messages successfully`);
}
