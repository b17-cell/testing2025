import cron from "node-cron";
import { checkAndSendReminders } from "./routes";

export function setupCronJobs() {
  // Run daily at 5:00 PM (17:00)
  // Cron format: minute hour day month weekday
  cron.schedule("0 17 * * *", async () => {
    console.log("⏰ Cron job triggered: Daily report check at 5:00 PM");
    try {
      await checkAndSendReminders();
    } catch (error) {
      console.error("❌ Cron job failed:", error);
    }
  });

  console.log("✅ Cron jobs scheduled: Daily check at 5:00 PM");
}
