// Integration with Google Sheets using the connector blueprint
import { google } from 'googleapis';

let connectionSettings: any;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=google-sheet',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('Google Sheet not connected');
  }
  return accessToken;
}

// WARNING: Never cache this client.
// Access tokens expire, so a new client must be created each time.
// Always call this function again to get a fresh client.
export async function getUncachableGoogleSheetClient() {
  const accessToken = await getAccessToken();

  const oauth2Client = new google.auth.OAuth2();
  oauth2Client.setCredentials({
    access_token: accessToken
  });

  return google.sheets({ version: 'v4', auth: oauth2Client });
}

// Helper functions for THE SHIFT HR Agent
export interface DailyReportRow {
  date: string;
  memberName: string;
  telegramChatId: string;
  telegramUsername?: string;
  submitted: string; // "Yes" or "No"
  submittedAt?: string;
}

export interface ReminderLogRow {
  date: string;
  memberName: string;
  reminderSentAt: string;
  messageContent: string;
  aiTone: string;
}

const SPREADSHEET_ID = process.env.GOOGLE_SHEET_ID || '';

// Check if Google Sheets is configured
export function isGoogleSheetsConfigured(): boolean {
  return !!SPREADSHEET_ID && SPREADSHEET_ID.length > 0;
}

export async function getTeamMembersFromSheet(): Promise<Array<{
  name: string;
  telegramChatId: string;
  telegramUsername?: string;
}>> {
  if (!isGoogleSheetsConfigured()) {
    console.log('⚠️  GOOGLE_SHEET_ID not configured - using sample data');
    return getSampleTeamMembers();
  }

  const sheets = await getUncachableGoogleSheetClient();
  
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: 'Team Members!A2:C100', // Assuming: Name, Telegram Chat ID, Telegram Username
    });

    const rows = response.data.values || [];
    return rows
      .filter(row => row[0] && row[1])
      .map(row => ({
        name: row[0],
        telegramChatId: row[1],
        telegramUsername: row[2] || undefined,
      }));
  } catch (error) {
    console.error('Error reading team members from Google Sheets:', error);
    return [];
  }
}

export async function getTodayReportsFromSheet(): Promise<DailyReportRow[]> {
  if (!isGoogleSheetsConfigured()) {
    return [];
  }

  const sheets = await getUncachableGoogleSheetClient();
  const today = new Date().toISOString().split('T')[0];
  
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: 'Daily Reports!A2:F1000', // Date, Name, Chat ID, Username, Submitted, Submitted At
    });

    const rows = response.data.values || [];
    return rows
      .filter(row => row[0] === today)
      .map(row => ({
        date: row[0],
        memberName: row[1],
        telegramChatId: row[2],
        telegramUsername: row[3] || undefined,
        submitted: row[4] || 'No',
        submittedAt: row[5] || undefined,
      }));
  } catch (error) {
    console.error('Error reading daily reports from Google Sheets:', error);
    return [];
  }
}

export async function logReminderToSheet(reminderLog: ReminderLogRow): Promise<void> {
  if (!isGoogleSheetsConfigured()) {
    console.log('⚠️  GOOGLE_SHEET_ID not configured - skipping sheet logging');
    return;
  }

  const sheets = await getUncachableGoogleSheetClient();
  
  try {
    await sheets.spreadsheets.values.append({
      spreadsheetId: SPREADSHEET_ID,
      range: 'Reminder Logs!A:E',
      valueInputOption: 'USER_ENTERED',
      requestBody: {
        values: [[
          reminderLog.date,
          reminderLog.memberName,
          reminderLog.reminderSentAt,
          reminderLog.messageContent,
          reminderLog.aiTone,
        ]],
      },
    });
  } catch (error) {
    console.error('Error logging reminder to Google Sheets:', error);
    throw error;
  }
}

export async function getAllReminderLogsFromSheet(): Promise<ReminderLogRow[]> {
  if (!isGoogleSheetsConfigured()) {
    return [];
  }

  const sheets = await getUncachableGoogleSheetClient();
  
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: 'Reminder Logs!A2:E1000',
    });

    const rows = response.data.values || [];
    return rows.map(row => ({
      date: row[0],
      memberName: row[1],
      reminderSentAt: row[2],
      messageContent: row[3],
      aiTone: row[4],
    }));
  } catch (error) {
    console.error('Error reading reminder logs from Google Sheets:', error);
    return [];
  }
}

// Sample data for testing when Google Sheets is not configured
function getSampleTeamMembers(): Array<{
  name: string;
  telegramChatId: string;
  telegramUsername?: string;
}> {
  return [
    {
      name: 'Sarah Johnson',
      telegramChatId: '123456789',
      telegramUsername: 'sarahj',
    },
    {
      name: 'Michael Chen',
      telegramChatId: '987654321',
      telegramUsername: 'mchen',
    },
    {
      name: 'Emma Rodriguez',
      telegramChatId: '456789123',
      telegramUsername: 'emmarodriguez',
    },
    {
      name: 'David Kim',
      telegramChatId: '789123456',
      telegramUsername: 'davidkim',
    },
    {
      name: 'Lisa Patel',
      telegramChatId: '321654987',
      telegramUsername: 'lisap',
    },
  ];
}
