// Gemini AI integration for generating personalized reminder messages
import { GoogleGenAI } from "@google/genai";

// DON'T DELETE THIS COMMENT
// Follow these instructions when using this blueprint:
// - Note that the newest Gemini model series is "gemini-2.5-flash" or gemini-2.5-pro"
//   - do not change this unless explicitly requested by the user

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generateReminderMessage(
  memberName: string,
  tone: "professional" | "friendly" | "urgent",
  customMessage?: string
): Promise<string> {
  if (customMessage) {
    return customMessage;
  }

  const toneInstructions = {
    professional: "Write in a professional and respectful tone, suitable for a workplace environment.",
    friendly: "Write in a warm, friendly, and encouraging tone that motivates the team member.",
    urgent: "Write in an urgent but respectful tone that emphasizes the importance of submitting the report today.",
  };

  const prompt = `You are an HR AI assistant for THE SHIFT marketing agency. Generate a personalized daily report reminder message for ${memberName}.

${toneInstructions[tone]}

The message should:
- Be concise (2-3 sentences max)
- Remind them to submit their daily report
- Be motivating and positive
- Include a friendly sign-off from THE SHIFT team

Do NOT include subject lines, headers, or greetings like "Dear" - just the message body.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || `Hi ${memberName}, friendly reminder to submit your daily report for today. Your contributions help keep the team aligned! - THE SHIFT Team`;
  } catch (error) {
    console.error('Error generating AI reminder message:', error);
    // Fallback message
    return `Hi ${memberName}, this is a friendly reminder to submit your daily report for today. Thank you! - THE SHIFT Team`;
  }
}
